// function build(description) {
//   var d = new Date();
//   var timeOfDay = d.getHours();
//
//   var body = document.querySelector("body");
//
//   console.log(timeOfDay);
//
//   if(timeOfDay >= 20 || timeOfDay < 6) {
//     body.style.backgroundImage = 'url(imgs/moonlight.jpg)';
//   }
//   else if(timeOfDay >= 6 || timeOfDay < 8) {
//     body.style.backgroundImage = 'url(imgs/sunrise.jpeg)';
//   }
//   else if(timeOfDay >= 8 || timeOfDay < 18) {
//     body.style.backgroundImage = 'url(imgs/)'
//   }
// }
