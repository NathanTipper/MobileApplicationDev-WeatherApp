var d = new Date();
var timeOfDay = 6;//d.getHours();

var body = document.querySelector("body");

if(timeOfDay >= 20 || timeOfDay < 6) {
  body.style.backgroundImage = 'url(imgs/moonlight.jpg)';
}
else if(timeOfDay >= 6 || timeOfDay < 8) {
  body.style.backgroundImage = 'url(imgs/sunrise.jpeg)';
}
